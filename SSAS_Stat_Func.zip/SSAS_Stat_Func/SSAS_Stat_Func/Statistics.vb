Public Class Statistics

    Public Function GetPValue(ByVal t As Double, ByVal n As Long) As Double
        Dim PiD2 As Double = Math.PI / 2
        t = Math.Abs(t)

        Dim w As Double = t / Math.Sqrt(n)
        Dim th As Double = Math.Atan(w)

        If (n = 1) Then
            Return 1 - th / PiD2
        End If

        Dim sth As Double = Math.Sin(th)
        Dim cth As Double = Math.Cos(th)

        If ((n Mod 2) = 1) Then
            Return 1 - (th + sth * cth * StatCom(cth * cth, 2, n)) / PiD2
        Else
            Return 1 - sth * StatCom(cth * cth, 1, n)
        End If
    End Function

    Function StatCom(ByVal q As Double, ByVal i As Long, ByVal j As Long) As Double
        Dim zz As Double = 1
        Dim z As Double = zz
        Dim k As Long = i

        While (k <= (j - 3))
            zz = zz * q * k / (k + 1)
            z = z + zz
            k = k + 2
        End While

        Return z
    End Function

End Class


