CREATE DATABASE [PairedT-Test]
GO

USE [PairedT-Test]
GO

CREATE TABLE [dbo].[ObservationFact] (
	[TrialId] [int] NOT NULL ,
	[PersonId] [int] NOT NULL ,
	[PersonWeight] [decimal](18, 0) NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[PersonDim] (
	[PersonId] [int] NOT NULL ,
	[FullName] [varchar] (50)
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[TrialDim] (
	[TrialId] [int] NOT NULL ,
	[TrialName] [varchar] (50)
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[ObservationFact] ADD 
	CONSTRAINT [PK_ObservationFact] PRIMARY KEY  CLUSTERED 
	(
		[TrialId],
		[PersonId]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[PersonDim] ADD 
	CONSTRAINT [PK_Person] PRIMARY KEY  CLUSTERED 
	(
		[PersonId]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[TrialDim] ADD 
	CONSTRAINT [PK_TrialDim] PRIMARY KEY  CLUSTERED 
	(
		[TrialId]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[ObservationFact] ADD 
	CONSTRAINT [FK_ObservationFact_PersonDim] FOREIGN KEY 
	(
		[PersonId]
	) REFERENCES [dbo].[PersonDim] (
		[PersonId]
	),
	CONSTRAINT [FK_ObservationFact_TrialDim] FOREIGN KEY 
	(
		[TrialId]
	) REFERENCES [dbo].[TrialDim] (
		[TrialId]
	)
GO

--TrialDim
INSERT INTO TrialDim (TrialId, TrialName) VALUES (1, N'Before')
INSERT INTO TrialDim (TrialId, TrialName) VALUES (2, N'After')

--PersonDim
INSERT INTO PersonDim (PersonId, FullName) VALUES (1, N'Keyser Soze')
INSERT INTO PersonDim (PersonId, FullName) VALUES (2, N'Sam Kane')
INSERT INTO PersonDim (PersonId, FullName) VALUES (3, N'Francis Bacon')
INSERT INTO PersonDim (PersonId, FullName) VALUES (4, N'Milton Friedman')
INSERT INTO PersonDim (PersonId, FullName) VALUES (5, N'Carl Sagan')
INSERT INTO PersonDim (PersonId, FullName) VALUES (6, N'David Attenborough')
INSERT INTO PersonDim (PersonId, FullName) VALUES (7, N'Karl Popper')
INSERT INTO PersonDim (PersonId, FullName) VALUES (8, N'Steven Pinker')

--ObservationFact
INSERT INTO ObservationFact (TrialId, PersonId, PersonWeight) VALUES (1, 1, 162)
INSERT INTO ObservationFact (TrialId, PersonId, PersonWeight) VALUES (1, 2, 170)
INSERT INTO ObservationFact (TrialId, PersonId, PersonWeight) VALUES (1, 3, 184)
INSERT INTO ObservationFact (TrialId, PersonId, PersonWeight) VALUES (1, 4, 164)
INSERT INTO ObservationFact (TrialId, PersonId, PersonWeight) VALUES (1, 5, 172)
INSERT INTO ObservationFact (TrialId, PersonId, PersonWeight) VALUES (1, 6, 176)
INSERT INTO ObservationFact (TrialId, PersonId, PersonWeight) VALUES (1, 7, 159)
INSERT INTO ObservationFact (TrialId, PersonId, PersonWeight) VALUES (1, 8, 170)
INSERT INTO ObservationFact (TrialId, PersonId, PersonWeight) VALUES (2, 1, 168)
INSERT INTO ObservationFact (TrialId, PersonId, PersonWeight) VALUES (2, 2, 136)
INSERT INTO ObservationFact (TrialId, PersonId, PersonWeight) VALUES (2, 3, 147)
INSERT INTO ObservationFact (TrialId, PersonId, PersonWeight) VALUES (2, 4, 159)
INSERT INTO ObservationFact (TrialId, PersonId, PersonWeight) VALUES (2, 5, 143)
INSERT INTO ObservationFact (TrialId, PersonId, PersonWeight) VALUES (2, 6, 161)
INSERT INTO ObservationFact (TrialId, PersonId, PersonWeight) VALUES (2, 7, 143)
INSERT INTO ObservationFact (TrialId, PersonId, PersonWeight) VALUES (2, 8, 145)



